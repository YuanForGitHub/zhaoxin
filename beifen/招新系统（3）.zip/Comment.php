<?php
//***********************************************
header("Content-Type: text/html; charset=utf-8");
include 'conn.php';
//***********************************************

//插入留言*********************************************************************************************************
if(isset($_POST['name'])){
date_default_timezone_set('PRC');//设置时区为本地时间
$strEx = "20";
$string = date("y-m-d  h:i:sa");
$string = $strEx.$string;
$sql = "INSERT INTO comment(name, comment, shijian) VALUES('{$_POST['name']}', '{$_POST['comment']}', '$string')";
if(mysqli_query($conn, $sql)){
    //echo "Success";
}
else{
    echo "Failed: ".$conn->error;
}
}
//*****************************************************************************************************************
?>


    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <!-- 设置图标 -->
        <link href="img/logo_icon.png" rel="icon" type="image/x-icon">
        <!-- 引入样式表 -->
        <link href="bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-responsive.css">
        <!-- 引入js -->
        <script src="http://code.jquery.com/jquery.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <title>留言区</title>
        <style>
            body {
                background-image: url('img/logo.jpg');
                background-repeat: no-repeat;
            }
            
            @media screen and (max-width: 480px) {
                .container {
                    border: 1px solid white;
                    margin-top: 1%;
                    padding-top: 2%;
                }
            }
            
            @media screen and (min-width: 480px) {
                .container {
                    border: 1px solid white;
                    box-shadow: 0px 0px 70px 3px lightgray;
                    margin-top: 1%;
                    padding-top: 2%;
                }
            }
            
            .liuyan {
                margin: 1% 3%;
                padding: 2%;
            }
            
            .odd {
                background-color: #E8F1F5;
            }
            
            #fayan {
                position: fixed;
                right: 1%;
                bottom: 1%;
            }
            
            #back {
                display: block;
                background-color: lightblue;
                opacity: 0.6;
                text-decoration: none;
                padding: 1%;
                border: 1px solid #7577CD;
                border-radius: 8px;
                position: fixed;
                z-index: +1;
                right: -1%;
                top: 48%;
            }
            
            #back:hover {
                opacity: 1;
            }
        </style>
    </head>

    <body>
        <div class="container">
            <div>
                <!-- 头部 -->
                <div class="header text-center">
                    <h4>留言区</h4>
                    <ol class="breadcrumb">
                        <li>华南农业大学 <span>/</span></li>
                        <li>数学与信息学院、软件学院 <span>/</span></li>
                        <li>团委学生会</li>
                    </ol>
                </div>

                <!-- 留言内容 -->
                <div>
                    <?php
                include 'conn.php';
                $perpage = 10;//每页显示数量
                $sql = "SELECT count(comment) FROM comment";//计算comment数量
                $result = mysqli_query($conn, $sql);
                $rows = mysqli_fetch_array($result)[0];//把总数赋给$rows
                $totalpages = ceil($rows/$perpage);//计算总页数
                if(empty($_GET['page'])){
                    $page = 1;
                }
                else{
                    $page = $_GET['page'];
                }

                $start = ($page-1) * $perpage;
                $sql = mysqli_query($conn, "SELECT * FROM comment LIMIT $start, $perpage");
                $color=0;
                while($row=mysqli_fetch_array($sql)){
                    if($color%2!=0){
                        echo "<div class='liuyan odd'>";
                    }
                    else{
                        echo "<div class='liuyan'>";
                    }
                    $color++;
                    echo "<em>"."&nbsp".$row['name']."&nbsp&nbsp".$row['shijian']."</em>"."<br><br>";
                    echo "<bold>&nbsp&nbsp&nbsp&nbsp".$row['comment']."</bold>";
                    echo "</div>";
                }
                ?>
                </div>

                <!--HTML页码显示-->
                <div id="page" class="text-center">
                    <?php
            for($i=1; $i<=$totalpages; $i++){
                if($i==$page)
                echo '<a class="btn btn-info" href="#">'.$i.'</a>';
                else
                echo sprintf('<a class="btn btn-link" href="%s?page=%d">%d</a>', $_SERVER['PHP_SELF'], $i, $i);
            }
            ?>
                </div>
                <hr>

                <!-- 尾部 -->
                <hr>
                <div class="text-center">
                    <p>Copyright © College of Information and College of Software</p>
                    <p>Powerd By NetMan</p>
                </div>
            </div>

        </div>
        <a href="index.html" id="back">
           返<br><br>回
        </a>
        <a href="#" data-toggle="modal" data-target="#message" id="fayan"><img src="img/message.png"></a>

        <div class="modal fade" id="message" tabindex="-1" role="dialog" aria-labelledby="message">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="message">发表言论</h4>
                    </div>
                    <div class="modal-body">
                        <form class="row-fluid" method="post" action="Comment.php">
                            输入昵称：
                            <input type="text" name="name" class="span4" placeholder="如“宇宙第一帅" />
                            <textarea name="comment" id="message" class="span12" rows="10" placeholder="(400字以内)"></textarea>
                            <button type="button" class="btn btn-default pull-right" data-dismiss="modal">Close</button>
                            <input type="submit" class="pull-right btn btn-info" value="submit">
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </body>

    </html>