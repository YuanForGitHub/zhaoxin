<?php
include 'conn.php';
if(isset($_POST['bz'])){
    
$id = $_POST['id'];
$bz = $_POST['bz'];

$sql = mysqli_query($conn, "UPDATE xinsheng SET bz='$bz' WHERE id=$id");
if($sql === TRUE){
    echo "Success!";
}
else{
    echo "Failed: ".$conn->error;
}
}
?>