<?php
include 'conn.php';

//检测用户登录情况
//……代码

//插入新生报名信息
$sql = "INSERT INTO xinsheng(name, xb, qq, lianxi_c, ss, zy, xh, aihao, jj, hq, zhiyuan_1, zhiyuan_2, fc, lq) 
        VALUES('{$_POST['name']}', '{$_POST['xb']}', '{$_POST['qq']}', '{$_POST['lianxi_c']}', '{$_POST['ss']}',
         '{$_POST['zy']}', '{$_POST['xh']}', '{$_POST['aihao']}', '{$_POST['jj']}', '{$_POST['hq']}', 
         '{$_POST['zhiyuan_1']}', '{$_POST['zhiyuan_2']}', '{$_POST['fc']}', '')";
$result = mysqli_query($conn, $sql);
if($result === TRUE){
    echo "Success!";
    header("Refresh: 1; url=index.html");
}
else{
    echo "Failed: ".$conn->error;
}
?>