<?php
include 'conn.php';

if(isset($_POST['xh'])){
    $xh = $_POST['xh'];
    $sql = mysqli_query($conn, "SELECT * FROM xinsheng WHERE xh='$xh'");
    if(mysqli_num_rows($sql)>0){
        $row = mysqli_fetch_array($sql);
        echo '<script>alert("恭喜你被'.$row['lq'].'录取了~");</script>"';
    }
    else{
        echo '<script>alert("没有看到你的录取消息哦~")</script>';
    }
    header('Refresh:0; url=Check.php');
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-responsive.css">
    <script src="js/jquery.min.js"></script>
    <script type="text/JavaScript" src="js/collapse.js"></script>
    <style>
        div {
            border: 1px solid white;
        }
        
        #back {
            display: block;
            background-color: lightblue;
            opacity: 0.6;
            text-decoration: none;
            padding: 1%;
            border: 1px solid #7577CD;
            border-radius: 8px;
            position: fixed;
            z-index: +1;
            right: -1%;
            top: 48%;
        }
        #Card {
            border: 1px solid white;
            box-shadow: 0px 0px 70px 3px lightgray;
            margin-top: 10%;
            padding: 6% 0%;
        }
        #back:hover {
            opacity: 1;
        }
    </style>
</head>

<body style="overflow-X:hidden">
    <div class="container row-fluid">
        <div class="span3"></div>
        <!-- 卡片 -->
        <div id="Card" class="text-center span6">
            <h3>查询录取结果</h3>
            <form class="form-inline" action="Check.php" method="post">
                <label>输入学号查询：</label>
                <input type="text" name="xh">
                <input type="submit" class="btn btn-info" value="提交">
            </form>
            <!--footer-->
            <hr>
            <div class="row-fluid text-center">
                <p>华南农业大学团学招生</p>
            </div>
        </div>

        <div class="span3"></div>
    </div>

    <a href="index.html" id="back">
           返<br><br>回
        </a>
</body>

</html>