<?php 
include 'conn.php'; 
//验证登录
session_start();
if(!isset($_SESSION['uname'])){
    echo "Failed";
    header("Refresh: 1; url = index.html");
    exit();
}

//已经面试登记
if(isset($_GET['ms'])){
    $id = $_GET['ms'];
    $sql = mysqli_query($conn, "UPDATE xinsheng SET ms='已经面试' WHERE id = $id");
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-responsive.css">
    <script src="js/jquery.min.js"></script>
    <script type="text/JavaScript" src="js/collapse.js"></script>
    <style>
        div {
            border: 1px solid white;
        }
        #change{
                display: block;
                background-color: lightblue;
                opacity: 0.6;
                text-decoration: none;
                padding: 1%;
                border: 1px solid #7577CD;
                border-radius: 8px;
                position: fixed;
                z-index: +1;
                left: -1%;
                top: 48%;
            }
        #back {
            display: block;
            background-color: lightblue;
            opacity: 0.6;
            text-decoration: none;
            padding: 1%;
            border: 1px solid #7577CD;
            border-radius: 8px;
            position: fixed;
            z-index: +1;
            right: -1%;
            top: 48%;
        }
        
        #back:hover {
            opacity: 1;
        }
    </style>
</head>

<body>

    <!--标题-->
    <div class="container">
        <div class="hero-unit text-center">
            <h2>面试界面</h2>
        </div>
        
        <!--显示-->
        <div class="row-fluid">
            <div class="span1"></div>
            <div class="span10">
                <table class="table table-striped table-bordered table-hover">
                    <?php
                    include 'conn.php';
                    $num = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM xinsheng WHERE ms is NULL"));
                    echo "<tr><th>总共有".$num."人需要面试</th></tr>";//显示面试人数
                    //显示标题
                    echo '<tr>
                    <th>姓名</th>
                    <th>第一志愿</th>
                    <th>第二志愿</th>
                    <th>是否服从</th>
                    <th>查看</th>
                    <th>面试</th>
                </tr>';
                //显示新生信息
                    $read = mysqli_query($conn, "SELECT * FROM xinsheng ORDER BY zhiyuan_1");
                    while($row = mysqli_fetch_array($read)){
                        echo "<tr>";
                        echo "<td>".$row['name']."</td><td>".$row['zhiyuan_1']."</td><td>".$row['zhiyuan_2']."</td><td>".$row['fc']."</td>";
                        echo "<td><a class='btn btn-warning' href='chakan.php?id={$row['id']}' target='blank'>查看信息</a></td>";
                        if($row['ms']==NULL){
                            echo "<td><a class='btn btn-success' href='mianshi.php?ms={$row['id']}'>结束面试</a></td>";
                        }
                        else{
                            echo "<td>".$row['ms']."</td></tr>";
                        }
                    }
                    ?>
                </table>
            </div>
            <div class="span1"></div>
        </div>

        <!--footer-->
        <hr>
        <div class="row-fluid text-center">
            <p>Copyright © College of Information and College of Software</p>
            <p>Powerd By NetMan</p>
        </div>

    </div>

    <a href="index.html" id="back">
           返<br><br>回
        </a>

    <a href="luqu.php" id="change">
        切<br><br>换
    </a>
</body>

</html>