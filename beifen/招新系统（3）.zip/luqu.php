<?php
include 'conn.php';

//验证登录
//验证登录
session_start();
if(!isset($_SESSION['uname'])){
    echo "Failed";
    header("Refresh: 1; url = index.html");
    exit();
}


//删除录取结果
if(isset($_GET['del'])){
    $id = $_GET['del'];
    $sql = mysqli_query($conn, "UPDATE xinsheng SET lq='' WHERE id=$id");
}

//录取新生
if(isset($_POST['lq'])){
    $lq = $_POST['lq'];//二面的时候改成二面
    $id = $_POST['id'];
    $sql = mysqli_query($conn, "UPDATE xinsheng SET lq='$lq' WHERE id=$id");
}
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-responsive.css">
        <script src="js/jquery.min.js"></script>
        <script type="text/JavaScript" src="js/collapse.js"></script>
        <style>
            div {
                border: 1px solid white;
            }
            #change{
                display: block;
                background-color: lightblue;
                opacity: 0.6;
                text-decoration: none;
                padding: 1%;
                border: 1px solid #7577CD;
                border-radius: 8px;
                position: fixed;
                z-index: +1;
                left: -1%;
                top: 48%;
            }
            #back {
                display: block;
                background-color: lightblue;
                opacity: 0.6;
                text-decoration: none;
                padding: 1%;
                border: 1px solid #7577CD;
                border-radius: 8px;
                position: fixed;
                z-index: +1;
                right: -1%;
                top: 48%;
            }
            
            #back:hover {
                opacity: 1;
            }
        </style>
    </head>

    <body>


        <div class="container">
            <!--标题-->
            <div class="hero-unit text-center">
                <h2>录取结果</h2>
            </div>

            <!-- 显示结果 -->
            <div class="row-fluid">
                <h3 class="text-center">已经录取</h3>
                <?php
                $read = mysqli_query($conn, "SELECT * FROM xinsheng WHERE lq!='' ORDER BY zhiyuan_1");
                if(mysqli_num_rows($read)>0){
                    echo "<table class=' table table-striped table-bordered table-hover'><tr><th>姓名</th><th>第一志愿</th><th>第二志愿</th><th>录取结果</th><th>个人信息</th><th>删除</th></tr>";
                }
                while($row = mysqli_fetch_array($read)){
                    echo "<tr>";
                    echo "<td>".$row['name']."</td><td>".$row['zhiyuan_1']."</td><td>".$row['zhiyuan_2']."</td>";
                    echo "<td>".$row['lq']."</td>";
                    echo "<td><a class='btn btn-warning' href='chakan.php?id={$row['id']}' target='blank'>查看信息</a></td>";
                    echo "<td><a class='btn btn-danger' href='luqu.php?del={$row['id']}'>取消录取</a></td>";
                    echo "</tr>";
                }
                echo "</table>";
                echo "<hr>";
                echo "<h3 class='text-center'>未被录取</h3>";
                $read = mysqli_query($conn, "SELECT * FROM xinsheng WHERE lq='' ORDER BY zhiyuan_1");
                echo "<table class=' table table-striped table-bordered table-hover'><tr><th>姓名</th><th>第一志愿</th><th>第二志愿</th><th>是否服从</th><th>录取部门</th><th>个人信息</th><th>录取</th></tr>";
                while($row = mysqli_fetch_array($read)){
                    echo "<tr>";
                    echo "<td>".$row['name']."</td><td>".$row['zhiyuan_1']."</td><td>".$row['zhiyuan_2']."</td>";
                    echo "<td>".$row['fc']."</td>";
                    echo '<td><form action="luqu.php" method="post">
                        <select name="lq">
                    <option value="">请选择</option>	
                    <option value="组织部">组织部</option>	
                    <option value="宣传部">宣传部</option>	
                    <option value="实践部">实践部</option>	
                    <option value="青年志愿者服务队">青年志愿者服务队</option>	
                    <option value="新闻部">新闻部</option>	
                    <option value="网络部">网络部</option>	
                    <option value="编辑部">编辑部</option>	
                    <option value="秘书部">秘书部</option>	
                    <option value="年级管理委员会">年级管理委员会</option>	
                    <option value="学习部">学习部</option>	
                    <option value="生活权益部">生活权益部</option>	
                    <option value="体育部">体育部</option>	
                    <option value="文娱部">文娱部</option>	
                    <option value="公关部">公关部</option>	
                        </select><input type="hidden" value="'.$row['id'].'" name="id"></td>';
                    echo "<td><a class='btn btn-warning' href='chakan.php?id={$row['id']}' target='blank'>查看信息</a></td>";
                    echo "<td><input type='submit' class='btn btn-success' value='录取'></form></td>";
                    echo "</tr>";
                }
                ?>
            </div>
        </div>

        <a href="index.html" id="back">
           返<br><br>回
        </a>
        <a href="mianshi.php" id="change">
            切<br><br>换
        </a>
    </body>

    </html>