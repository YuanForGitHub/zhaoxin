<?php 
include 'conn.php'; 
//验证登录
session_start();
if(!isset($_SESSION['uname'])){
    echo "Failed";
    header("Refresh: 1; url = index.html");
    exit();
}

//读取信息
$id = $_GET['id'];
$sql = mysqli_query($conn, "SELECT * FROM xinsheng WHERE id=$id");
$row = mysqli_fetch_array($sql);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>查看个人信息</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-responsive.css">
    <script src="js/jquery.min.js"></script>
    <script type="text/JavaScript" src="js/collapse.js"></script>
    <style>
        body{
            background-image: url('img/logo.jpg');
        }
        .container {
            border: 1px solid white;
            box-shadow: 0px 0px 70px 3px lightgray;
            margin-top: 1%;
            padding: 3%;
            width: 60%;
        }
        
    </style>
</head>

<body>
    <div class="container">
        <!-- 头部 -->
        <div class="header">
            <h3><?php echo $row['name'];?></h3>
            <ol class="breadcrumb">
                <li>首页 <span>/</span></li>
                <li>面试界面 <span>/</span></li>
                <li>新生个人信息</li>
            </ol>
        </div>

        <!-- 信息 -->
        <div>
            <?php
            echo "<label>专业：".$row['zy']."</label><br>";
            echo "<label>学号：".$row['xh']."</label><br>";
            echo "<label>爱好：".$row['aihao']."</label><br>";
            echo "<label>简介：".$row['jj']."</label><br>";
            echo "<label>想在团学收获什么：".$row['hq']."</label><br>";
            ?>
        </div>

        <!-- 备注 -->
        <div>
            <form>
                <label>备注：</label>
                <textarea id="bz" rows="10" class="span8" name="bz" placeholder="(在400字之内哦~)" ><?php echo $row['bz']; ?></textarea>
                <div class="row-fluid">
                    <button type="button" class="btn btn-info span2" id="submit">提交</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        $(function(){
            $("#submit").click(function(){
                $.post("beizhu.php", { id:<?php echo $row['id'];?>, bz: $("#bz").val()});
                alert('提交成功！');
            })
        })
    </script>

</body>

</html>